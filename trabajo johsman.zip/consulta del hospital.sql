SELECT * FROM pacientes;
SELECT * FROM citas;
SELECT * FROM medicos;