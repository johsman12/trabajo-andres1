-- voy a crear la data para la base de datos tienda en linea y en primer lugar para los clientes
INSERT INTO clientes (Id_cliente,Nombre_cliente,correo_electronico) VALUES
(1,"Sofia","sofia@gmail.com"),
(2,"Camilo", "camilo@gmail.com"),
(3,"Karen","karen@gmail.com"),
(4,"Paula","paula@gmail.com");
-- voy a crear la data para la base de datos tienda en linea para los productos
INSERT INTO productos (Id_producto,Nombre_producto,Descripcion_producto,Codigo_producto,Precio) VALUES
(6,"Tablet Samsung A8","Pantalla 10.5, 64GB almacenamiento","8754","165000"),
(7,"Auriculares Bluetooth Xiaomi","Audífonos inalambricos con microfono","007","86500"),
(8,"Lampara LED de escritorio","Luz blanca con brazo flexible y puerto USB","008","72400"),
(9,"Equipo de sonido","Sistema de audio 700W con Bluetooth y USB","009","855600");
-- voy a crear la data para la base de datos tienda en linea para las pedidos
INSERT INTO pedidos (Id_pedido,Id_cliente,Id_producto,Fecha_pedido,cantidad) VALUES
(20,"1","9","2025-03-01","8"),
(21,"2","8","2025-03-05","12"),
(22,"3","7","2025-03-08","5"),
(23,"4","6","2025-03-10","15");