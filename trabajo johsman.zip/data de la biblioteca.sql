-- voy a crear la data para la base de datos biblioteca y en primer lugar para los usuarios
INSERT  INTO usuarios (Id_usuario,Nombre_usuario,Direccion,Codigo_usuario) VALUES
(1,"Daniel","Calle 20 N 10-185, Popayán, Cauca","7896"),
(2,"josé","Calle 21 N 10-164, bolivar, Cauca","3412"),
(3,"sofia","Calle 5 N 15-131, Popayán, Cauca","8410"),
(4,"camila","Calle 6 N 8-189, bordo, Cauca","6437");
-- voy a crear la data para la base de datos biblioteca para los libros
INSERT INTO libros (Id_libro,Titulo_libro,Autor_libro,Añopublicacion,Codigo_usuario) VALUES 
(14,"Infocracia","Byung-Chul Han","2022-10-10","4675"),
(15,"Las hijas de la criada","Sonsoles Ónega","2023-08-24","4081"),
(16,"Un animal salvaje","Joël Dicker","2024-09-08","3916"),
(17,"La asistenta","Freida McFadden","2021-11-22","0261");
-- voy a crear la data para la base de datos biblioteca para los prestamos
INSERT INTO prestamos (Id_prestamo,Id_usuario,Id_libro,Fechaprestamo,Fechaentrega,Codigo_prestamo) VALUES
(20,"1","14","2025-03-08","2025-03-15","08712"),
(21,"2","16","2025-04-10","2025-04-19","1768"),
(22,"3","15","2025-05-12","2025-05-19","8540"),
(23,"4","17","2025-06-04","2025-06-12","1623");

