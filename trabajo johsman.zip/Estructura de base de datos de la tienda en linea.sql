-- vamos a crear la base de datos
CREATE DATABASE IF NOT EXISTS tienda1 ;
-- voy a utilizar la base creada
USE tienda1;
-- creo la primer tabla idependiente para la primer entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS clientes(
Id_cliente INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_cliente VARCHAR(50) NOT NULL,
correo_electronico VARCHAR(50) NOT NULL
);
-- ahora creo la segunda tabla independiente a partir de el modelo MER
CREATE TABLE IF NOT EXISTS productos(
Id_producto INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_producto VARCHAR(50) NOT NULL,
Descripcion_producto VARCHAR(50) NOT NULL,
Codigo_producto INT NOT NULL,
Precio DECIMAL(10,2) NOT NULL
);
-- vamos a crear la tabla dependiente,para la entidad pedido que es tambien dependiente
CREATE TABLE IF NOT EXISTS pedidos(
Id_pedido INT UNIQUE NOT NULL PRIMARY KEY,
Id_cliente INT NOT NULL,
Id_producto  INT NOT NULL,
Fecha_pedido DATE NOT NULL,
cantidad INT NOT NULL,

CONSTRAINT fk_tienda_cliente FOREIGN KEY (Id_cliente) REFERENCES clientes (Id_cliente),
CONSTRAINT fk_tienda_producto FOREIGN KEY (Id_producto) REFERENCES productos (Id_producto)
);