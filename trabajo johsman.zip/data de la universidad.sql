-- voy a crear la data para la base de datos universidad y en primer lugar para los estudiantes
INSERT INTO estudiantes (Id_estudiante,Nombre_estudiante,Numeromatricula,Correo_eletronico,Codigo_estudiante) VALUES
(1,"nairo","2025110947","nairo@gmail.com","1092"), 
(2,"luis","2025103493","luis@gmail.com","2864"),
(3,"fernanda","2025203412","fernanda@gmail.com","3932"),
(4,"juliana","2025402309","juliana@gmail.com","4987");
-- voy a crear la data para la base de datos univesidad para los cursos
INSERT INTO cursos (Id_curso,Codigo_curso,Numeromatricula,Nombre_curso,Numerocredito,Codigo_profesor) VALUES
(6,"c500a","2025243567","contabilidad","4","6709"),
(7,"lit350a","2025105823","literatura","3","2316"),
(8,"mat101","2025981205","matematicas","2","7540"),
(9,"fin4cr","2025457621","Finanzas","1","6597");
-- voy a crearcla data para la base de datos universidad para los profesore
INSERT INTO profesores (Id_profesor,Id_estudiante,Id_curso,Nombre_profesor,Especialidad,Codigo_profesor) VALUES
(11,"1","6","josé","contabilidad","6709"),
(12,"3","8","rubiela","matematicas","7540"),
(13,"2","7","betty","literatura","2316"),
(14,"4","9","deiro","finanzas","6597");