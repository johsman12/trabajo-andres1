-- voy a crear la data para la base de datos hospital y en primer lugar para los pacientes
INSERT INTO pacientes (Id_paciente,Nombre_paciente,Numhistoriaclinica,Direccion,Telefono,Codigo_paciente) VALUES
(1,"javier","HC-2025-45098","Calle 20 N 10-185","3146759865","6702"),
(2,"jairo","HC-2025-75924","Calle 5 N 15-175","3116874334","5430"),
(3,"amberto","HC-2025-45237","Calle 15 N 9-168","3135670983","3286"),
(4,"ernesto","HC-2025-43198","Calle 9 N 11-126","3204560972","5487");
-- voy a crear la data para la base de datos hospital para las citas
INSERT INTO citas (Fecha,Numcolegiatura,Numhistoriaclinica,Hora) VALUES
(2025-08-15,"clp-15873","hcp-0329-2025","09:30:00"),
(2024-02-29,"cm-2025-049","hcp-0511-2024","14:45:00"),
(2026-01-01,"890321","hcp-1104-2023","18:00:00"),
(2023-11-20,"med-c-774a","hcp-0099-2025","21:15:00");