-- voy a crear la data para la base de datos 
CREATE DATABASE IF NOT EXISTS universidad;
-- voy a utilizar la base creada
USE universidad;
-- creo la primer tabla idependiente para la primer entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS estudiantes(
Id_estudiante INT UNIQUE NOT NULL PRIMARY KEY,
Nombre_estudiante VARCHAR(50) NOT NULL,
Numeromatricula VARCHAR(50) NOT NULL,
Correo_eletronico VARCHAR(50) NOT NULL,
Codigo_estudiante INT NOT NULL
);
-- ahora creo la segunda tabla independiente a partir del modelo MER
CREATE TABLE IF NOT EXISTS cursos(
Id_curso INT UNIQUE NOT NULL PRIMARY KEY,
Codigo_curso VARCHAR(50) NOT NULL,
Numeromatricula VARCHAR(50) NOT NULL,
Nombre_curso VARCHAR(50) NOT NULL,
Numerocredito VARCHAR(50) NOT NULL,
Codigo_profesor INT NOT NULL
);
-- ahora vamos a crear la tabla dependiente para la entidad profesor que es tambien dependiente
CREATE TABLE IF NOT EXISTS profesores(
Id_profesor INT UNIQUE NOT NULL PRIMARY KEY,
Id_estudiante INT NOT NULL,
Id_curso INT NOT NULL,
Nombre_profesor VARCHAR(50) NOT NULL,
Especialidad VARCHAR(50) NOT NULL,
Codigo_profesor INT NOT NULL,

CONSTRAINT fk_profesor_estudiante FOREIGN KEY (Id_estudiante) REFERENCES estudiantes (Id_estudiante),
CONSTRAINT fk_profesor_curso FOREIGN KEY (Id_curso) REFERENCES cursos (Id_curso)
);


