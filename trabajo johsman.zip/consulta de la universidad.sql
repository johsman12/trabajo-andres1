SELECT * FROM estudiantes;
SELECT * FROM cursos;
SELECT * FROM profesores;