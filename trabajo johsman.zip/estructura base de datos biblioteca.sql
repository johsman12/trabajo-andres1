-- Vamos a crear la base de datos 
CREATE DATABASE IF NOT EXISTS STORE;
-- voy a utilizar la base de datos creada 
USE STORE;
-- creo la primer tabla independiente para la primer entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS usuarios(
Id_usuario int UNIQUE NOT NULL PRIMARY KEY,
Nombre_usuario VARCHAR(50) NOT NULL,
Direccion VARCHAR(50) NOT NULL,
Codigo_usuario INT NOT NULL 
);
-- ahora creo la segunda tabla independiente a partir del modelo MER
CREATE TABLE IF NOT EXISTS libros(
Id_libro INT UNIQUE NOT NULL PRIMARY KEY,
Titulo_libro VARCHAR(50) NOT NULL,
Autor_libro VARCHAR(50) NOT NULL,
Añopublicacion DATE NOT NULL, 
Codigo_usuario INT NOT NULL
);
-- ahora creamos la tabla independiente para la entidad factura que es tambien dependiente
CREATE TABLE IF NOT EXISTS prestamos(
Id_prestamo INT UNIQUE NOT NULL PRIMARY KEY,
Id_usuario INT NOT NULL,
Id_libro INT NOT NULL,
Fechaprestamo DATE NOT NULL,
Fechaentrega DATE NOT NULL,
Codigo_prestamo INT NOT NULL,

CONSTRAINT fk_prestamo_usuario FOREIGN KEY (Id_usuario) REFERENCES usuarios (Id_usuario),
CONSTRAINT fk_prestamo_libro FOREIGN KEY (Id_libro) REFERENCES libros (Id_libro)
 );