-- vamos a crear la base de datos 
CREATE DATABASE IF NOT EXISTS hospital;
-- voy a utilizar la base creada 
USE hospital;
-- creo la primer tabla independiente para la primer entidad independiente del modelo MER
CREATE TABLE IF NOT EXISTS pacientes(
Id_paciente INT UNIQUE NOT NULL PRIMARY KEY,  
Nombre_paciente VARCHAR(50) NOT NULL,
Numhistoriaclinica VARCHAR(50) NOT NULL,
Direccion VARCHAR(50) NOT NULL,
Telefono VARCHAR(50) NOT NULL,
Codigo_paciente INT NOT NULL
);
-- ahora creo la segunda tabla independiente a partir del modelo MER
CREATE TABLE IF NOT EXISTS citas(
Fecha INT UNIQUE NOT NULL PRIMARY KEY,
Numcolegiatura VARCHAR(50) NOT NULL,
Numhistoriaclinica VARCHAR(50) NOT NULL,
Hora INT NOT NULL
);
-- ahora vamos a crear la tabla dependiente para la entidad medico que es tambien dependiente
CREATE TABLE IF NOT EXISTS medicos(
Id_medico INT UNIQUE NOT NULL PRIMARY KEY,
Id_paciente INT NOT NULL,
Fecha INT NOT NULL,
Numcolegiatura DATE NOT NULL,
Nombre VARCHAR(50) NOT NULL,
Atributos INT NOT NULL,

CONSTRAINT fk_medico_paciente FOREIGN KEY (Id_paciente) REFERENCES pacientes (Id_paciente),
CONSTRAINT fk_medico_citas FOREIGN KEY (Fecha) REFERENCES citas (Fecha)
);
