SELECT * FROM clientes;
SELECT * FROM productos;
SELECT * FROM pedidos;